#### Specifications of HW1
- The structure of the files provided in HW1
    ```
    hw1
    ├── README.md
    ├── hw1-q1.c
    ├── hw1-q2.c
    ├── hw1-q3.c
    ├── hw1-q4.c
    ├── hw1.pdf
    └── q1-ans.txt
    ```
- Please **TYPE** your answers rather than hand-write.
- Write down your full name, student ID and all textual parts (e.g., q2, q3, and q4) into a pdf file named *hw1-ans.pdf*. 
- Put your files into a folder named with your *student ID* and compress it into a ZIP file *StudentID.zip*, i.e., your submission shall follow exact the same structure as below.
    ```
    1155xxxxxx.zip
    1155xxxxxx
    ├── hw1-q4.c
    ├── hw1-ans.pdf
    └── q1-ans.txt
    ```
