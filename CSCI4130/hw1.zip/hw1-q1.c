#include <stdio.h>
#include <math.h>
int func1(int a, int b, int c) {
    int l;
    int *m = (int *)malloc(sizeof(int));
    int n;
    l = temp(a, b);
    *m = a + b + c * l;
    n = *m - c;
    return n;
}

int temp(int x, int y){
    int result = 0;
    result = pow(x, y);
    return result + 2;
}

int main(){
    char test_string[] = "csci4130";
    return func1(-1, 1, 1024);
}
