int* malloc_int(int size) {
    int* p = (int*)malloc(sizeof(int) * size);
    return p;
}

void func2() {
    char str[20];
    gets(str);
    int* len = malloc_int(1);
    int* str1 = malloc_int(20);
    int* save_str1 = str1;
    *len = strlen(str);
    for(int i = 0; i < *len; i ++){
        str1[i] += str[i];
    }
    free(len); len=NULL;
    free(str1); str1=NULL;
    free(save_str1); save_str1=NULL;
    return;
}
