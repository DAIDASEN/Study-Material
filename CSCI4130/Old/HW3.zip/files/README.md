#### Submission format of homework 3
- You are asked to put all your files in a folder titled <studentID>, and package this folder into <studentID.zip>. The files inside the folder should follow the designated names and format as below. You are not allowed to modify or change the file names.

    |- studentID.zip
        |- studentID
            |-- studentID.pdf
            |-- q3b.jpg
            |-- q4b.jpg