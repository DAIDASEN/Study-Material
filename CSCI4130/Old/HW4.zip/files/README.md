#### Submission format of homework 4
- In this homework, you have to complete a PDF report and related script(s).
- You are asked to put all your files in a folder titled <StudentID>, and package this folder into <StudentID.zip>. The files inside the folder should follow the designated format as below.

    |- StudentID.zip
        |- StudentID
            |-- hw4_report.pdf
            |-- q1-a.py
            |-- q1-b.py
